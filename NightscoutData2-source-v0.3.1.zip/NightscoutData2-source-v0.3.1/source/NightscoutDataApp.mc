/*
 * NightscoutData Garmin Connect IQ data field application
 * Copyright (C) 2017 tynbendad@gmail.com
 * #WeAreNotWaiting
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3 of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   A copy of the GNU General Public License is available at
 *   https://www.gnu.org/licenses/gpl-3.0.txt
 */

using Toybox.Application as App;
using Toybox.Background;
using Toybox.Time;
using Toybox.System as Sys;

// info about whats happening with the background process
var canDoBG=false;
var setupReqd=false;

// background data, shared directly with appview
var bgdata;

// keys to the object store data
var OSDATA="osdata";

(:background)
class NightscoutDataApp extends App.AppBase {
    var myView;
    var offsetSeconds = 30;
    var shiftingOffset = false;
	var syncAtSecond = -1;

    function initialize() {
        AppBase.initialize();
        //Sys.println("App initialize");
    }

    // onStart() is called on application start up
    function onStart(state) {
    }

    // onStop() is called when your application is exiting
    function onStop(state) {
    }

	function setNextEvent(seconds) {
        Background.registerForTemporalEvent(new Time.Duration(seconds));
        var nextLoad = Time.now().value() + (seconds);
        App.getApp().setProperty("nextLoad", nextLoad);
    }

    function fetchSettings() {
        var thisApp = Application.getApp();
        var nsurl = thisApp.getProperty("nsurl");
        var offlineUrl = thisApp.getProperty("offlineUrl");

        if (((nsurl != null) && !nsurl.equals("")) ||
            ((offlineUrl != null) && !offlineUrl.equals(""))) {
            //Sys.println("onSettingsChanged: set 5 minute event - nsurl=" + nsurl + " elapsedMinutesMin=" + elapsedMinutesMin);
            setupReqd=false;
        } else {
            //Sys.println("onSettingsChanged: invalid nsurl, not starting background process");
            setupReqd=true;
        }

        var temp = thisApp.getProperty("syncAtSecond");
        if (temp!=null && temp instanceof Number) {
        	if (syncAtSecond != temp) {
	        	syncAtSecond=temp;
	        	//Sys.println("syncAtSecond="+syncAtSecond);
		        if ((syncAtSecond >= 0) && (syncAtSecond < (5*60))) {
		        	resync(0);
	        	}
        	}
    	}
    }

    function onSettingsChanged() {
        //myPrintLn("in onSettingsChanged");
        offsetSeconds = 30;
        App.getApp().setProperty("offsetSeconds", offsetSeconds);
		fetchSettings();

        myView.settingsChanged();
        //myPrintLn("out onSettingsChanged");
    }

    // Return the initial view of your application here
    function getInitialView() {
        //register for temporal events if they are supported
        myView = new NightscoutDataView();
        if(Toybox.System has :ServiceDelegate) {
            canDoBG=true;
            Background.deleteTemporalEvent();
            var thisApp = Application.getApp();
	        var temp = thisApp.getProperty("offsetSeconds");
            if (temp!=null && temp instanceof Number) {
            	offsetSeconds=temp;
            	Sys.println("from OS: offsetSeconds="+offsetSeconds);
        	}
            fetchSettings();
	        setNextEvent(5 * 60);
        } else {
            //Sys.println("****background not available on this device****");
        }
        return [ myView ];
    }

	function resync(elapsedMills) {
        var myMoment = new Time.Moment(elapsedMills / 1000);
        var nextEventSeconds;
        if ((syncAtSecond < 0) || (syncAtSecond >= (5*60))) {
        	// auto-sync:
            var elapsedSeconds = Time.now().subtract(myMoment).value();
            Sys.println("elapsedSeconds="+elapsedSeconds+", now="+Time.now().value()+", elapsedMills="+elapsedMills);
            if ((elapsedSeconds >= (5 * 60)) &&
            	(elapsedSeconds < (10 * 60))) {
            	if (shiftingOffset) {
            		offsetSeconds += 60;
            		offsetSeconds = offsetSeconds % (5 * 60);
            	} else {
            		// wait for a 2nd 5-9 minute elapsed, to confirm we are out of sync, not just a missed reading
            		shiftingOffset = true;
            	}
        	} else {
        		shiftingOffset = false;
        	}
            nextEventSeconds = 5 * 60 + (offsetSeconds - (elapsedSeconds % (5 * 60)));
            //Sys.println("onBackgroundData: elapsedSeconds="+elapsedSeconds+", offsetSeconds="+offsetSeconds+", shiftingOffset="+shiftingOffset);
        } else {
        	// manual sync:
            var curTime = Time.now().value();
        	var nextTime = curTime - (curTime % (5*60));
        	nextTime += syncAtSecond + 5*60;
        	nextEventSeconds = nextTime - curTime;
        	Sys.println("manual sync: syncAtSecond="+syncAtSecond+", now="+curTime+", nextTime="+nextTime);
        }
        while (nextEventSeconds < 5 * 60) {
        	if (nextEventSeconds > ((5 * 60) - 30)) {
        		nextEventSeconds = 5 * 60;
        	} else {
                nextEventSeconds += (5 * 60);
            }
        }
		Sys.println("nextEventSeconds="+nextEventSeconds);
        setNextEvent(nextEventSeconds);
	}

    function onBackgroundData(data) {
        var now=Sys.getClockTime();
        var ts=now.hour+":"+now.min.format("%02d");
        Sys.println("onBackgroundData="+data+" at "+ts);
        if ((data != null) &&
            data.hasKey("elapsedMills") &&
            (data["elapsedMills"] > 0)) {
            //Sys.println("onBackgroundData: check sync");
            setupReqd=false;

            var elapsedMills = data["elapsedMills"].toLong();
            resync(elapsedMills);
            //Sys.println("onBackgroundData update property");
            App.getApp().setProperty(OSDATA,data);
            bgdata = data;
            //Ui.requestUpdate();
        } else {
	        setNextEvent(5 * 60);
        }
        App.getApp().setProperty("offsetSeconds", offsetSeconds);
    }

    function getServiceDelegate(){
        //var now=Sys.getClockTime();
        //var ts=now.hour+":"+now.min.format("%02d");
        //Sys.println("getServiceDelegate: "+ts);
        return [new BgbgServiceDelegate()];
    }

}