/*
 * NightscoutData Garmin Connect IQ data field application
 * Copyright (C) 2017 tynbendad@gmail.com
 * #WeAreNotWaiting
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3 of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   A copy of the GNU General Public License is available at
 *   https://www.gnu.org/licenses/gpl-3.0.txt
 */

using Toybox.Background;
using Toybox.Communications;
using Toybox.System as Sys;

// The Service Delegate is the main entry point for background processes
// our onTemporalEvent() method will get run each time our periodic event
// is triggered by the system.

(:background)
class BgbgServiceDelegate extends Toybox.System.ServiceDelegate {
    var reqNum = 0;

    function initialize() {
        Sys.ServiceDelegate.initialize();
    }

    function printMem() {
        var myStats = System.getSystemStats();
        Sys.println("mem total: " + myStats.totalMemory + ", used: " + myStats.usedMemory + ", free: " + myStats.freeMemory);
        //Sys.println("memory: free: " + System.getSystemStats().freeMemory);
    }

	function dirToString(direction) {
/* dictionary takes several KB more than just using if/else, and datafield only has 32KB to work with.
        var dirSwitch = { "SingleUp" => "Up",
                          "DoubleUp" => "Up^2",
                          "FortyFiveUp" => "Up/",
                          "FortyFiveDown" => "Down\",
                          "SingleDown" => "Down",
                          "DoubleDown" => "Down^2",
                          "Flat" => "Flat",
                          "NONE" => "NONE" };
        if (dirSwitch.hasKey(direction)) {
            direction = dirSwitch[direction];
        }
*/
        return direction;
	}

	function removeWhitespace(url) {
		while(!url.equals("") &&
		      url.substring(0,1).equals(" ")) {
		    url = url.substring(1,url.length());
        }
		while(!url.equals("") &&
		      url.substring(url.length()-1,url.length()).equals(" ")) {
		    url = url.substring(0,url.length()-1);
        }
        while(url.substring(url.length()-1,url.length()).equals("/")) {
		    url = url.substring(0,url.length()-1);
        }
        if (url.substring(url.length()-9,url.length()).equals("/sgv.json")) {
		    url = url.substring(0,url.length()-9);
        }
		return url;
	}

    function makeNSURL() {
        var thisApp = Application.getApp();
        var sugarmate = false;
        var url = thisApp.getProperty("nsurl");
		if (url == null) { url = ""; }
		
		url = removeWhitespace(url);

        if (!url.equals("")) {
        	var options = "";
	        if (url.find("://") == null) {
    	        url = "https://" + url;
        	}
	        if (url.find("?") != null) {
	        	// support token based nightscout authentication, set NS URL = your-site.herokuapp.com?token=your-token
	        	options = url.substring(url.find("?"),url.length());
			    url = url.substring(0,url.find("?"));
				url = removeWhitespace(url);
	        }
	        if (url.find("sugarmate.io/api/") != null) {
	        	sugarmate = true;
		        if (url.toLower().find("http://") != null) {
				   url = url.substring(url.toLower().find("http://")+7,url.length());
	    	       url = "https://" + url;
    	        }
	        } else {
	            url = url + "/api/v2/properties/bgnow,rawbg,delta";
            }
	        url = url + options;
    	}
        return [url, sugarmate];
	}

    function makeOfflineURL() {
        var thisApp = Application.getApp();
		var url = thisApp.getProperty("offlineUrl");
		if (url == null) { url = ""; }

		url = removeWhitespace(url);

        if (url.equals("")) {
        	if ((reqNum % 2) == 0) {
        		url = "X";
        	} else {
        		url = "S";
        	}
        }

        if (url.substring(0,1).toUpper().equals("X")) {
            url = "http://127.0.0.1:17580"; // xdrip+ local web server
        } else if (url.substring(0,1).toUpper().equals("S")) {
            url = "http://127.0.0.1:1979"; // Spike web server
        }

        if (!url.equals("")) {
	        if (url.find("://") == null) {
	            url = "http://" + url;
	        }
	        url = url + "/sgv.json?count=6";
        }
        //url = "https://tynbendad.github.io/pumptest/api/v1/diabox2023.json";
        //url = "https://tynbendad.github.io/pumptest/xdrip/otherapp1.json";
        return url;
    }

    function onReceive(responseCode, data) {
        //myPrintLn("in onReceive()");
        //myPrintLn("response: " + responseCode.toString());
        var bgdata = {};
        if ((responseCode == 200) &&
            (data != null) &&
            !data.isEmpty()) {
            var elapsedMills, bg, direction, delta, rawbg;
            elapsedMills = 0;
            bg = -1;
            direction = "";
            delta = "";
            rawbg = "";

            if (data.hasKey("bgnow")) {
                if (data["bgnow"].hasKey("mills")) {
                    //myPrintLn(data["bgnow"]["mills"].toString());
                    elapsedMills = data["bgnow"]["mills"];
                }
                if (data["bgnow"].hasKey("sgvs") &&
                    (data["bgnow"]["sgvs"].size() > 0) &&
                    data["bgnow"]["sgvs"][0].hasKey("scaled")) {
                    //myPrintLn(data["bgnow"]["sgvs"][0]["scaled"].toString());
                    bg = data["bgnow"]["sgvs"][0]["scaled"];
                } else if (data["bgnow"].hasKey("sgvs") &&
                           (data["bgnow"]["sgvs"].size() > 1) &&
                           data["bgnow"]["sgvs"][1].hasKey("scaled")) {
                    //myPrintLn(data["bgnow"]["sgvs"][1]["scaled"].toString());
                    bg = data["bgnow"]["sgvs"][1]["scaled"];
                }
                // bg = mmol_or_mgdl(bg);
                if (data["bgnow"].hasKey("sgvs") &&
                    (data["bgnow"]["sgvs"].size() > 0) &&
                    data["bgnow"]["sgvs"][0].hasKey("direction")) {
                    //myPrintLn(data["bgnow"]["sgvs"][0]["direction"].toString());
                    direction = dirToString(data["bgnow"]["sgvs"][0]["direction"].toString());
                    //myPrintLn(direction);
                }
            }

            if (data.hasKey("delta") &&
                data["delta"].hasKey("display")) {
                //myPrintLn(data["delta"]["display"].toString());
                delta = data["delta"]["display"].toString();
            }

            if (data.hasKey("rawbg") &&
                data["rawbg"].hasKey("mgdl") &&
                data["rawbg"].hasKey("noiseLabel")) {
                //rawbg = "raw:" + data["rawbg"]["mgdl"].toString() + " " + data["rawbg"]["noiseLabel"];
                rawbg = data["rawbg"]["mgdl"].toString();
                //myPrintLn(rawbg);
            }

            if (bg == -1) {
            	Sys.println("no bg ??? data="+data);
        	} else {
	            bgdata["elapsedMills"] = elapsedMills;
	            bgdata["bg"] = bg;
	            bgdata["direction"] = direction;
	            bgdata["delta"] = delta;
	            bgdata["rawbg"] = rawbg;
        	}
        } else {
            Sys.println("onReceive failed with " + responseCode.toString());
	        var url = makeOfflineURL();
            if (!url.equals("")) {
                //Sys.println("url: " + url.toString());
                reqNum++;
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
                return;
            }
        }
        printMem();
        Background.exit(bgdata);
    }

    function onReceiveSGV(responseCode, data) {
        //myPrintLn("in onReceiveSGV()");
        //myPrintLn("response: " + responseCode.toString());
        var bgdata = {};
        if ((responseCode == 200) &&
            (data != null) &&
            (data.size() > 1) &&
            (data[0] != null) &&
            (data[1] != null) &&
            !data[0].isEmpty() &&
            !data[1].isEmpty()
            ) {
            var elapsedMills, bg, direction, delta, isMgdl;
            elapsedMills = 0;
            bg = 0;
            direction = "";
            delta = "";
            isMgdl = true;
            if (data[0].hasKey("units_hint")) {
            	if (!data[0]["units_hint"].equals("mgdl")) {
            		isMgdl = false;
            	}
            }

            if (data[0].hasKey("sgv") &&
                data[0].hasKey("date") &&
                data[0].hasKey("direction")
                ) {
                elapsedMills = data[0]["date"];
                bg = data[0]["sgv"];
                if ((bg instanceof Number) &&
                	!isMgdl) {
	                bg = bg / 18.0;
		            bg = bg.format("%.1f");
                }
                direction = dirToString(data[0]["direction"].toString());
                delta = "N/A";
                if (data[1].hasKey("sgv") &&
                    data[1].hasKey("date")) {
                    var deltaTime;
                    var indexForDelta = 1;
                	var deltaGoalMinute = (((data[0]["date"] - (5 * 60000)) / 1000 / 60.0) + 0.5).toNumber();
                    for (var i=1; i < data.size(); i++) {
                    	if ((data[i] != null) &&
				            !data[i].isEmpty() &&
    	                    data[i].hasKey("sgv") &&
        	            	data[i].hasKey("date")) {
        	            	var curDataMinute = ((data[i]["date"] / 1000 / 60.0) + 0.5).toNumber();
        	            	//Sys.println("i="+i+", deltaGoalMinute="+deltaGoalMinute+", curDataMinute="+curDataMinute);
	        	            if (curDataMinute >= deltaGoalMinute) {
	        	            	//Sys.println("found delta minute at index " + i);
	        	            	indexForDelta = i;
	                    	}
                    	}
                	}
        	        //Sys.println("using data["+indexForDelta+"] for delta");
            	    delta = data[0]["sgv"] - data[indexForDelta]["sgv"];
                	deltaTime = (data[0]["date"] - data[indexForDelta]["date"]) / 1000 / 300.0;
                    //myPrintLn("delta=" + delta + ", deltaTIme=" + deltaTime);

                    if ((deltaTime > 1.1) || ((deltaTime > 0) && (deltaTime < .9))) {
                        // convert >5.5 or <4.5 minute delta to to 5-minute delta
                        delta = (delta / deltaTime);
		                delta = delta.toNumber();
                    }
	                if (!isMgdl) {
		                delta = delta / 18.0;
		                delta = delta.format("%.1f");
	                }
                    if (deltaTime > 0) {
                        if (delta.toFloat() >= 0) {
                            delta = "+" + delta;
                        }
                    } else {
                        delta = "N/A";
                    }
                }
            }
            bgdata["elapsedMills"] = elapsedMills;
            bgdata["bg"] = bg;
            bgdata["direction"] = direction;
            bgdata["delta"] = delta;
        } else {
            Sys.println("onReceiveSGV failed with " + responseCode.toString());
	        var url = makeOfflineURL();
            if ((reqNum < 4 /*maxRequests*/) && !url.equals("")) {
                //Sys.println("url: " + url.toString());
                reqNum++;
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
                return;
            }
        }
        printMem();
        Background.exit(bgdata);
    }

    function onReceiveSugarmate(responseCode, data) {
        //Sys.println("in OnReceiveSugarmate");

        //Sys.println("response: " + responseCode.toString());
        var bgdata = {};
        if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof Dictionary)) {
            var elapsedMills = 0;
            if (data.hasKey("value") &&
                data.hasKey("x")) {
	            var bg, direction, delta, isMgdl; //, bgMgdl;
	            bg = 0;
	            //bgMgdl = 0;
	            direction = "";
	            delta = "";
	            isMgdl = true;
	            if (data.hasKey("units")) {
	            	if ((data["units"] != null) &&
	                	(data["units"] instanceof String) &&
	            		(data["units"].find("mmol") != null)) {
	            		isMgdl = false;
	            	}
	            }
                elapsedMills = data["x"].toLong() * 1000;
                bg = data["value"];
                //bgMgdl = bg;
                if (!isMgdl) {
	                bg = data["mmol"].format("%.1f");
		        }
                if (data.hasKey("trend") &&
                	(data["trend"] instanceof Number)) {
                	var sugarMateDirSwitch = ["None", "DoubleUp", "SingleUp", "FortyFiveUp", "Flat", "FortyFiveDown", "SingleDown", "DoubleDown", "NotComputable", "OutOfRange"];
	                if ((data["trend"] > 0) && (data["trend"] < sugarMateDirSwitch.size())) {
	                	direction = sugarMateDirSwitch[data["trend"]];
	                }
            	}
                if ((isMgdl && data.hasKey("delta")) ||
                	((!isMgdl) && data.hasKey("delta_mmol"))) {
	                if (isMgdl) {
		                delta = data["delta"].toString();
	                } else {
		                delta = data["delta_mmol"].format("%.1f");
	                }
                    if ((delta.find("+") == null) && (delta.toFloat() >= 0)) {
                        delta = "+" + delta;
                    }
                }
	            bgdata["bg"] = bg;
	            bgdata["direction"] = direction;
	            bgdata["delta"] = delta;
	            //Sys.println("valid data: " + data);
            //} else {
	            //Sys.println("invalid data: " + data);
            }
            bgdata["elapsedMills"] = elapsedMills;
        } else {
            Sys.println("Sugarmate resp: " + responseCode.toString());
            //Sys.println("data: " + data);
	        var url = makeOfflineURL();
            if (!url.equals("")) {
                //Sys.println("url: " + url.toString());
                reqNum++;
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
                return;
            }
        }
        printMem();
        //Sys.println("out OnReceiveSugarmate - exit, bgdata="+bgdata);

        Background.exit(bgdata);
    }

    function onTemporalEvent() {
        var nsurlRet = makeNSURL();
        var url = nsurlRet[0];
        var sugarmate = nsurlRet[1];
        reqNum = 0;
        if (!url.equals("")) {
	        //Sys.println("url: " + url);
            reqNum++;
			if (sugarmate) {
	            Communications.makeWebRequest(url, {}, {}, method(:onReceiveSugarmate));
    		} else { 
		        Communications.makeWebRequest(url, {}, {}, method(:onReceive));
	        }
        } else {
	        url = makeOfflineURL();
            if (!url.equals("")) {
                //Sys.println("url: " + url.toString());
                reqNum++;
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
            }
        }
    }


}
