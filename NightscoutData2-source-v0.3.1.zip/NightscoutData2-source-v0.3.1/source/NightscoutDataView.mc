/*
 * NightscoutData Garmin Connect IQ data field application
 * Copyright (C) 2017-2019 tynbendad@gmail.com
 * #WeAreNotWaiting
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3 of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   A copy of the GNU General Public License is available at
 *   https://www.gnu.org/licenses/gpl-3.0.txt
 */

using Toybox.WatchUi as Ui;
using Toybox.System as Sys;
using Toybox.Lang as Lang;
using Toybox.Application as App;
using Toybox.Time.Gregorian as Calendar;
using Toybox.FitContributor as Fit;
using Toybox.Time;
using Toybox.Graphics as Gfx;

class NightscoutDataView extends Ui.DataField {
    const viewVersion = "0.3.1";
	const timerMinuteHeight = 1;
	const BORDER_PAD_X = 6;
	const BORDER_PAD_Y = 2;
	const LABEL_Y_OFFSET = 2;
	const OBSCURITY_X = 0.94;
    const BGFITCONTRIB_FIELD_ID = 0;

    enum {
        bgDisplayFull           = 0,
        bgDisplayNoTrend        = 1,
        bgDisplayNoDelta        = 2,
        bgDisplayNoElapsed      = 3,
        bgDisplayNoTrendDelta   = 4,
        bgDisplayNoTrendElapsed = 5,
        bgDisplayNoDeltaElapsed = 6,
        bgDisplayBGOnly         = 7,
        bgDisplayBGElapsedRaw   = 8 }

    const arrow = [[4.0/8, 0], [7.0/8, 3.0/7], [5.0/8, 3.0/7], [5.0/8, 7.0/7], [3.0/8, 7.0/7], [3.0/8, 3.0/7], [1.0/8, 3.0/7], [4.0/8, 0]];
    const doubleArrow = [[8.0/17, 3.0/7], [5.0/17, 3.0/7], [5.0/17, 7.0/7], [3.0/17, 7.0/7], [3.0/17, 3.0/7], [0, 3.0/7], [4.0/17, 0], [8.0/17, 3.0/7],
    				   [17.0/17, 3.0/7], [14.0/17, 3.0/7], [14.0/17, 7.0/7], [12.0/17, 7.0/7], [12.0/17, 3.0/7], [9.0/17, 3.0/7], [13.0/17, 0], [17.0/17, 3.0/7]];
/* dictionary takes several KB more than just using if/else, and datafield only has 32KB to work with.
    const none = [[0, 0], [0, 0], [0, 0]];
    const dirSwitch = { "SingleUp" => [0, arrow],
                      "DoubleUp" => [0, doubleArrow],
                      "FortyFiveUp" => [45, arrow],
                      "FortyFiveDown" => [135, arrow],
                      "SingleDown" => [180, arrow],
                      "DoubleDown" => [180, doubleArrow],
                      "Flat" => [90, arrow],
                      "NONE" => [0, none] };
*/
	const alphaFonts = [Gfx.FONT_XTINY,Gfx.FONT_TINY,Gfx.FONT_SMALL,Gfx.FONT_MEDIUM,Gfx.FONT_LARGE];
	const numFonts = [Gfx.FONT_XTINY,Gfx.FONT_TINY,Gfx.FONT_SMALL,Gfx.FONT_MEDIUM,Gfx.FONT_LARGE,
	             Gfx.FONT_NUMBER_MILD,Gfx.FONT_NUMBER_MEDIUM,Gfx.FONT_NUMBER_HOT,Gfx.FONT_NUMBER_THAI_HOT];

    var displayMode = bgDisplayFull;
    var bgFitContribField = null;
    var showVersion = true;
    var fitlabel = "Nightscout";
	var settingChanged = true;

    hidden var mLabelFont = Gfx.FONT_XTINY;
	var errorFont = Gfx.FONT_SMALL;
    var width, height;
    var top, left;
    var layoutWidth, layoutHeight;
    var dirFgColor;

	var errorStr = "";
	var monitorStr = "";
	var bgStr = "";
	var elapsedStr = "";
	var deltaStr = "";
	var dirStr = "";
	var rawBgStr = "";
	var secondsToLoad = 0;
	var bgOld = true;

    // Set the label of the data field here.
    function initialize() {
    	//Sys.println("in initialize()");
        DataField.initialize();

        //read last values from the Object Store
        var temp=App.getApp().getProperty(OSDATA);
        if(temp!=null) {bgdata=temp;}

		settingsChanged();

        // Create the custom FIT data field we want to record.
        bgFitContribField = createField(
            fitlabel,
            BGFITCONTRIB_FIELD_ID,
            FitContributor.DATA_TYPE_FLOAT,
            {:mesgType=>Fit.MESG_TYPE_RECORD, :units=>"bg" }
        );
        bgFitContribField.setData(0.0);

        var now=Sys.getClockTime();
        var ts=now.hour+":"+now.min.format("%02d");
        Sys.println("From OS: data="+bgdata+" at "+ts);
        //Sys.println("From OS: data="+bgdata+" elapsedMinutesMin="+elapsedMinutesMin+" at "+ts);
    	//Sys.println("out initialize()");
    }

    function settingsChanged() {
    	//Sys.println("in settingsChanged()");
        displayMode = App.getApp().getProperty("bgDisplay");
        if (displayMode==null) { displayMode = bgDisplayFull; }
        if (displayMode < bgDisplayFull) { displayMode = bgDisplayFull; }
        if (displayMode > bgDisplayBGElapsedRaw) { displayMode = bgDisplayFull; }
        fitlabel = App.getApp().getProperty("fitlabel");
        if (fitlabel==null) { fitlabel = "NightscoutData"; }
        //Ui.requestUpdate();
        settingChanged = true;
    	//Sys.println("out settingsChanged()");
    }

    // The given info object contains all the current workout
    // information. Calculate a value and return it in this method.
    // Note that compute() and onUpdate() are asynchronous, and there is no
    // guarantee that compute() will be called before onUpdate().
    function compute(info) {
    	//Sys.println("in compute()");
        // See Activity.Info in the documentation for available information.
		var nextLoad = App.getApp().getProperty("nextLoad");
		var now = Time.now().value();
		secondsToLoad = 0;
		if (nextLoad != null) {
			secondsToLoad = nextLoad - now;
			//Sys.println("secondsToLoad="+secondsToLoad);
			if ((secondsToLoad < 0) || (secondsToLoad > 60 * 20)) {
				secondsToLoad = 0;
			}
		}
        errorStr = "Refresh: "+secondsToLoad + "s";
        monitorStr = "";
	    bgStr = "";
	    elapsedStr = "";
	    deltaStr = "";
	    dirStr = "";
	    rawBgStr = "";

        if (showVersion) {
            errorStr = "Version " + viewVersion /*App.getApp().getProperty("appVersion")*/;
            showVersion = false;
        } else if (!canDoBG) {
            errorStr = "Device unsupported";
        } else if (setupReqd &&
	               ((bgdata == null) ||
	                !bgdata.hasKey("bg"))) {
            errorStr = "Setup required";
        } else {
			if (!Sys.getDeviceSettings().phoneConnected) {
	            monitorStr = "!BT ";
            }

	        if ((bgdata != null) &&
	            bgdata.hasKey("bg")) {
		        errorStr = "";
	            bgStr = bgdata["bg"];
            	if ((bgdata["bg"] instanceof Float) ||
                	(bgdata["bg"] instanceof Number)) {
                	bgStr = bgdata["bg"].toString();
                }
                if (bgStr instanceof String) {
                	bgStr = bgStr.substring(0, 4);
			        if(bgStr.length() > 2 && bgStr.substring(bgStr.length()-2,bgStr.length()).equals(".0")) {
					    bgStr = bgStr.substring(0,bgStr.length()-2);
			        }
			        if(bgStr.length() > 1 && bgStr.substring(bgStr.length()-1,bgStr.length()).equals(".")) {
					    bgStr = bgStr.substring(0,bgStr.length()-1);
			        }
            	}
	            if ((bgdata["bg"] instanceof String) ||
	            	(bgdata["bg"] instanceof Float) ||
	                (bgdata["bg"] instanceof Number)) {
	                var bgfloat;
	                if (bgdata["bg"] instanceof String) {
	                	// attempt to avoid possibility of invalid value errors
	                	var safeBgStr = "0" + bgdata["bg"];
	                	bgfloat = safeBgStr.toFloat();
	                } else {
		                bgfloat = bgdata["bg"].toFloat();
	                }
	                bgFitContribField.setData(bgfloat);
		            // Sys.println(bgfloat.toString());
	            }
	        }

        	bgOld = true;
	        if ((bgdata != null) &&
	            bgdata.hasKey("elapsedMills")) {
	            var elapsedMills = bgdata["elapsedMills"];
	            var myMoment = new Time.Moment(elapsedMills / 1000);
	            var elapsedMinutes = Math.floor(Time.now().subtract(myMoment).value() / 60);
	            if (elapsedMinutes < 15) {
	            	bgOld = false;
	            }
	            if ((displayMode != bgDisplayNoElapsed) &&
		            (displayMode != bgDisplayNoTrendElapsed) &&
		            (displayMode != bgDisplayNoDeltaElapsed) &&
		            (displayMode != bgDisplayBGOnly)) {
		            var elapsed = elapsedMinutes.format("%d") + "m";
		            if ((elapsedMinutes > 9999) || (elapsedMinutes < -999)) {
		                elapsed = "";
		            }
		            elapsedStr = elapsed;
	            }
	        }

	        if ((bgdata != null) &&
	            bgdata.hasKey("delta") &&
	            (displayMode != bgDisplayNoDelta) &&
	            (displayMode != bgDisplayNoTrendDelta) &&
	            (displayMode != bgDisplayNoDeltaElapsed) &&
	            (displayMode != bgDisplayBGElapsedRaw) &&
	            (displayMode != bgDisplayBGOnly)) {
	            deltaStr = bgdata["delta"];
	        }

	        if ((bgdata != null) &&
	            bgdata.hasKey("direction") &&
	            (displayMode != bgDisplayNoTrend) &&
	            (displayMode != bgDisplayNoTrendDelta) &&
	            (displayMode != bgDisplayNoTrendElapsed) &&
	            (displayMode != bgDisplayBGElapsedRaw) &&
	            (displayMode != bgDisplayBGOnly)) {
	            dirStr = bgdata["direction"];
	        }

	        if ((bgdata != null) &&
	            bgdata.hasKey("rawbg") &&
	            (displayMode == bgDisplayBGElapsedRaw)) {
	            rawBgStr = bgdata["rawbg"];
	        }

			if (bgStr == null) { bgStr = ""; } else { bgStr = bgStr.toString(); }
			if (elapsedStr == null) { elapsedStr = ""; } else { elapsedStr = elapsedStr.toString(); }
			if (deltaStr == null) { deltaStr = ""; } else { deltaStr = deltaStr.toString(); }
			if (dirStr == null) { dirStr = ""; } else { dirStr = dirStr.toString(); }
			if (rawBgStr == null) { rawBgStr = ""; } else { rawBgStr = rawBgStr.toString(); }

            // debug:
            //var now=Sys.getClockTime();
            //var ts=now.hour+":"+now.min.format("%02d");
            //Sys.println(myStr1 + ", " + myStr2 + " at time " + ts);
	        //if (bgdata != null) {
	        	//Sys.println(bgdata);
	        //}
        }
    	//Sys.println("out compute()");
    }

    // Get the field layout
    // gist: we're just figuring out the field size and alignment (due to obscurities)
    //       onUpdate will have to figure out the rest since it knows the actual data (hence sizes)
    // outputs: width, height, top, left, layoutWidth, layoutHeight
    function onLayout(dc) {
    	//Sys.println("in onLayout()");
        width = dc.getWidth();
        height = dc.getHeight();
        var obscurityOffset = 0;

		//Sys.println("onLayout: obscurity="+getObscurityFlags());
		if (((getObscurityFlags() & OBSCURE_BOTTOM) != 0) &&
			((getObscurityFlags() & OBSCURE_TOP) == 0)) {
			// for bottom-obscured fields that aren't also top-obscured, use no label and align to top
			top = BORDER_PAD_Y;
	        layoutHeight = (height - top - (4 * BORDER_PAD_Y)) * 0.8;
		} else {
	        top = LABEL_Y_OFFSET + BORDER_PAD_Y
	        		// + Gfx.getFontHeight(mLabelFont);
					+ dc.getTextDimensions(fitlabel, mLabelFont)[1];
	        layoutHeight = height - top - (4 * BORDER_PAD_Y);
        }

        layoutWidth = width - (4 * BORDER_PAD_X);
		if ((getObscurityFlags() & OBSCURE_LEFT) != 0) {
			obscurityOffset += width * (1.0 - OBSCURITY_X);
			layoutWidth -= width * (1.0 - OBSCURITY_X);
			if ((getObscurityFlags() & (OBSCURE_TOP|OBSCURE_BOTTOM)) != 0) {
				obscurityOffset += width * (1.0 - OBSCURITY_X);
				layoutWidth -= width * (1.0 - OBSCURITY_X);
			}
		}
		if ((getObscurityFlags() & OBSCURE_RIGHT) != 0) {
			layoutWidth -= width * (1.0 - OBSCURITY_X);
			if ((getObscurityFlags() & (OBSCURE_TOP|OBSCURE_BOTTOM)) != 0) {
				layoutWidth -= width * (1.0 - OBSCURITY_X);
			}
		}
        left = 2 * BORDER_PAD_X + obscurityOffset;
        //Sys.println("onLayout: width="+width+", height="+height+", top="+top+", left="+left+", layoutWidth="+layoutWidth+", layoutHeight="+layoutWidth);
    	//Sys.println("out onLayout()");
    }

    function selectFont(dc, width, height, theStr, numOnly) {
        var fontIdx;
        var dimensions;

        //Search through fonts from biggest to smallest
        if (numOnly != 1) {
        	var largestIdx = alphaFonts.size() - 1;
        	var smallestIdx = 0;
	        for (fontIdx = largestIdx; fontIdx >= smallestIdx; fontIdx--) {
	            dimensions = dc.getTextDimensions(theStr, alphaFonts[fontIdx]);
	            dimensions[1] -= Gfx.getFontDescent(alphaFonts[fontIdx]);
	            if ((dimensions[0] <= width) && (dimensions[1] <= height)) {
	                //If this font fits, it is the biggest one that does
	                break;
	            }
	        }
        } else {
        	var largestIdx = numFonts.size() - 1;
        	var smallestIdx = 0;
	        for (fontIdx = largestIdx; fontIdx >= smallestIdx; fontIdx--) {
	            dimensions = dc.getTextDimensions(theStr, numFonts[fontIdx]);
	            dimensions[1] -= Gfx.getFontDescent(numFonts[fontIdx]);
	            if ((dimensions[0] <= width) && (dimensions[1] <= height)) {
	                //If this font fits, it is the biggest one that does
	                break;
	            }
	        }
        }

		//if (fontIdx < smallestIdx) {
			//Sys.println("didn't fit, numOnly="+numOnly+", dimensions="+dimensions);
		//}

        return [fontIdx, dimensions];
    }

	function transformCoords(coords, degrees, size, centerPoint) {
        var cos = Math.cos(Math.toRadians(degrees));
        var sin = Math.sin(Math.toRadians(degrees));
        var result = [];

        // Transform the coordinates
        for (var i = 0; i < coords.size(); i += 1) {
            var x = ((coords[i][0] - 0.5) * cos) - ((coords[i][1] - 0.5) * sin);
            var y = ((coords[i][0] - 0.5) * sin) + ((coords[i][1] - 0.5) * cos);
            x = (x + 0.5) * size + 0.5;
            y = (y + 0.5) * size + 0.5;

            result.add([centerPoint[0] + x, centerPoint[1] + y]);
        }

        return result;
	}

    function strikeThrough(dc, bgStr, theFont, textX, textY) {
    	var w = 1.1 * dc.getTextWidthInPixels(bgStr, theFont);
    	var h = Gfx.getFontHeight(theFont);
    	var x = textX - (w / 2);
    	var hOffset = h / 12;
    	var hSize = h / 16;
		var y = textY + (h / 2) - hOffset; // - (h / 8 / 2);
        dc.fillRectangle(x, y, w, hSize);
        dc.fillRectangle(x, y + (hOffset * 2), w, hSize);
    }

    // Update the field layout and display the field data
    // gist: use actual data to figure out sub-field sizes/loocations, and display data
    // inputs: <data: bgStr, elapsedStr, deltaStr, dirStr, ...>,
    //		   width, height, top, left, layoutWidth, layoutHeight, alignTop, alignLeft, alignRight
    function onUpdate(dc) {
    	//Sys.println("in onUpdate()");
//    	if (settingChanged) {
    		// some devices on simulator were not calling onLayout after a settings change and/or sim re-run
    		settingChanged = false;
    		onLayout(dc);
//    	}

		// calc layout with/for:
		//    dirStr -> dirIconX, dirIconY
		//    errorStr -> width/2, data1Y
		//    bgStr -> data1X, data1Y, mDataFont1
		//    elapsedStr -> data2X, data2Y, mDataFont2
		//    monitorStr -> data3X, data3Y, mDataFont3
		//    rawBgStr + deltaStr -> data3X, data3Y, mDataFont3
		// outputs:
		var mDataFont1, mDataFont2, mDataFont3, data1X, data1Y, data2X, data2Y, data3X, data3Y, dirIconX, dirIconY, dirSize;
		var xAlignment = Gfx.TEXT_JUSTIFY_CENTER;
		var xAlignment3 = Gfx.TEXT_JUSTIFY_CENTER;
		{
			var primarySubfieldFactor = 0.5;
			var primarySubfieldFactorV = 0.66;

			var numSecondarySubfields = 3;
			if ((dirStr.length() + rawBgStr.length() + deltaStr.length() + monitorStr.length() + elapsedStr.length()) == 0) {
				numSecondarySubfields = 1; // really 0, but can't divide by 0
				primarySubfieldFactor = 1.0;
				primarySubfieldFactorV = 1.0;
			} else if ((dirStr.length() + rawBgStr.length() + deltaStr.length() + monitorStr.length()) == 0) {
				numSecondarySubfields = 1;
				primarySubfieldFactor = 0.66;
			} else if (elapsedStr.length() == 0) {
				numSecondarySubfields = 2;
				primarySubfieldFactorV = 1.0;
			}

			// Sys.println("width="+width+", height="+height);
			// Sys.println("layoutWidth="+layoutWidth+", layoutHeight="+layoutHeight);

			// check horizontal layout, {1,2,3,4}x1
	        var layoutPair1 = selectFont(dc, layoutWidth * primarySubfieldFactor, layoutHeight, bgStr.toString(), 1);
	        var layoutFontIdx1 = layoutPair1[0];
	        var layoutDim1 = layoutPair1[1];
	        var subFieldMax = (layoutWidth - layoutDim1[0]) / numSecondarySubfields;
	        // Sys.println("layoutDim1="+layoutDim1+", subFieldMax="+subFieldMax);
	        var layoutPair2 = selectFont(dc, subFieldMax, layoutHeight, elapsedStr, 0);
	        var layoutFontIdx2 = layoutPair2[0];
	        var layoutDim2 = layoutPair2[1];
	        // Sys.println("layoutDim2="+layoutDim2);
	        var layoutPair3 = selectFont(dc, subFieldMax, layoutHeight, deltaStr + rawBgStr, 0);
	        var layoutFontIdx3 = layoutPair3[0];
	        var layoutDim3 = layoutPair3[1];
	        // Sys.println("layoutDim3="+layoutDim3);
	        if ((layoutFontIdx1 < 0) || (layoutFontIdx2 < 0) || (layoutFontIdx3 < 0)) {
	            //Sys.println("defaulting to smallest font - horiz");
				layoutFontIdx1 = 0;
	            layoutDim1 = dc.getTextDimensions(bgStr.toString(), numFonts[0]);
				layoutFontIdx2 = 0;
	            layoutDim2 = dc.getTextDimensions(elapsedStr.toString(), alphaFonts[0]);
				layoutFontIdx3 = 0;
	            layoutDim3 = dc.getTextDimensions(deltaStr.toString(), alphaFonts[0]);
            }

			// check vertical layout, {1,2}x{1,2}
	        var vlayoutPair1 = selectFont(dc, layoutWidth * primarySubfieldFactorV, layoutHeight / 2, bgStr.toString(), 1);
	        var vlayoutFontIdx1 = vlayoutPair1[0];
	        var vlayoutDim1 = vlayoutPair1[1];
	        var vsubField2Max = layoutWidth - vlayoutDim1[0] - BORDER_PAD_X;
	        // Sys.println("vlayoutDim1="+vlayoutDim1+", vsubField2Max="+vsubField2Max);
	        var vlayoutPair2 = selectFont(dc, vsubField2Max, layoutHeight / 2, elapsedStr, 0);
	        var vlayoutFontIdx2 = vlayoutPair2[0];
	        var vlayoutDim2 = vlayoutPair2[1];
	        var vsubField3Max = (layoutWidth - BORDER_PAD_X) / 2;
	        // Sys.println("vlayoutDim2="+vlayoutDim2+", vsubField3Max="+vsubField3Max);
	        var vlayoutPair3 = selectFont(dc, vsubField3Max, layoutHeight / 2, deltaStr + rawBgStr, 0);
	        var vlayoutFontIdx3 = vlayoutPair3[0];
	        var vlayoutDim3 = vlayoutPair3[1];
	        //Sys.println("layoutDim3="+vlayoutDim3);
	        if ((vlayoutFontIdx1 < 0) || (vlayoutFontIdx2 < 0) || (vlayoutFontIdx3 < 0)) {
	            //Sys.println("defaulting to smallest font - vert");
				vlayoutFontIdx1 = 0;
	            vlayoutDim1 = dc.getTextDimensions(bgStr.toString(), numFonts[0]);
				vlayoutFontIdx2 = 0;
	            vlayoutDim2 = dc.getTextDimensions(elapsedStr.toString(), alphaFonts[0]);
				vlayoutFontIdx3 = 0;
	            vlayoutDim3 = dc.getTextDimensions(deltaStr.toString(), alphaFonts[0]);
            }

			if ((layoutFontIdx1 + layoutFontIdx2 + layoutFontIdx3) >=
				(vlayoutFontIdx1 + vlayoutFontIdx2 + vlayoutFontIdx3)) {
				// use horizontal
		        mDataFont1 = numFonts[layoutFontIdx1];
		        mDataFont2 = alphaFonts[layoutFontIdx2];
		        mDataFont3 = alphaFonts[layoutFontIdx3];
		        dirSize = subFieldMax;
		        if (dirSize > layoutHeight) {
			        dirSize = layoutHeight;
		        }
		        if (dirStr.length() == 0) {
		        	dirSize = 0;
		        }
		        dirSize = Math.floor(dirSize);
		        // Sys.println("dirSize="+dirSize);
		        data1X = left 							// center just., main field
		        		 + layoutDim2[0] + BORDER_PAD_X	// left field padded width
		        		 + (layoutDim1[0] / 2);		   	// half center field width
		        data1X += (layoutWidth - (layoutDim1[0] + layoutDim2[0] + layoutDim3[0] + dirSize + (BORDER_PAD_X * 3))) / 2;
		        data2X = data1X - (layoutDim1[0] / 2) - BORDER_PAD_X - (layoutDim2[0] / 2); // center just., left field
		        data3X = data1X + (layoutDim1[0] / 2) + BORDER_PAD_X + (layoutDim3[0] / 2); // center just., right field
		        dirIconX = data3X + (layoutDim3[0] / 2) + BORDER_PAD_X;		// left just.

				dirFgColor = Gfx.COLOR_BLACK;
		        data1Y = top + ((layoutHeight - (Gfx.getFontHeight(mDataFont1) - Gfx.getFontDescent(mDataFont1))) / 2);
		        data2Y = top + ((layoutHeight - (Gfx.getFontHeight(mDataFont2) - Gfx.getFontDescent(mDataFont2))) / 2);
		        data3Y = top + ((layoutHeight - (Gfx.getFontHeight(mDataFont3) - Gfx.getFontDescent(mDataFont3))) / 2);
		        dirIconY = top + ((layoutHeight - (dirSize - Gfx.getFontDescent(mDataFont3))) / 2);
				//Sys.println("horz: data1X="+data1X+", data2X="+data2X+", data3X="+data3X+", dirIconX="+dirIconX);
			} else {
				// use vertical
		        mDataFont1 = numFonts[vlayoutFontIdx1];
		        mDataFont2 = alphaFonts[vlayoutFontIdx2];
		        mDataFont3 = alphaFonts[vlayoutFontIdx3];
		        dirSize = vsubField3Max;
		        if (dirSize > (layoutHeight / 2)) {
			        dirSize = layoutHeight / 2;
		        }
		        dirSize = Math.floor(dirSize);
		        // Sys.println("vert: dirSize="+dirSize+", center1="+center1);
		        data1X = left + (vlayoutDim1[0] / 2);	// center just.
		        data1X += (layoutWidth - (vlayoutDim1[0] + vlayoutDim2[0] + BORDER_PAD_X)) / 2;
		        data2X = data1X + (vlayoutDim1[0] / 2) + BORDER_PAD_X + (vlayoutDim2[0] / 2); // center just.
		        data3X = left + (vlayoutDim3[0] / 2);	// center just.
		        data3X += (layoutWidth - (vlayoutDim3[0] + dirSize + BORDER_PAD_X)) / 2;
		        dirIconX = data3X + (vlayoutDim3[0] / 2) + BORDER_PAD_X;		// left just.

				dirFgColor = Gfx.COLOR_BLACK;
		        data1Y = top + (((layoutHeight/2) - (Gfx.getFontHeight(mDataFont1) - Gfx.getFontDescent(mDataFont1))) / 2);
		        data2Y = top + (((layoutHeight/2) - (Gfx.getFontHeight(mDataFont2) - Gfx.getFontDescent(mDataFont2))) / 2);
		        data3Y = top + (layoutHeight/2) + (((layoutHeight/2) - (Gfx.getFontHeight(mDataFont3) - Gfx.getFontDescent(mDataFont3))) / 2);
		        dirIconY = top + (layoutHeight/2) + (((layoutHeight/2) - (dirSize - Gfx.getFontDescent(mDataFont3))) / 2);
				//Sys.println("vert: data1X="+data1X+", data2X="+data2X+", data3X="+data3X+", dirIconX="+dirIconX);
			}
		}

        var bgColor = getBackgroundColor();
        var fgColor = Gfx.COLOR_BLACK;

        if (bgColor == Gfx.COLOR_BLACK) {
            fgColor = Gfx.COLOR_WHITE;
            if (dirFgColor == Gfx.COLOR_BLACK) {
            	dirFgColor = Gfx.COLOR_WHITE;
            }
        }

        dc.setColor(fgColor, bgColor);
        dc.clear();

		// Draw the refresh timer
		dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
		var minutesToLoad = secondsToLoad / 60;
		var secondsMod60 = secondsToLoad % 60;
		var labelY;
		var drawLabel = true;
		if (((getObscurityFlags() & OBSCURE_BOTTOM) != 0) &&
			((getObscurityFlags() & OBSCURE_TOP) == 0)) {
			// don't use a label on bottom-obscured fields, for more room since they're likely also right/left obscured
			labelY = BORDER_PAD_Y;
			drawLabel = false;
		} else {
	        labelY = LABEL_Y_OFFSET + BORDER_PAD_Y
					+ dc.getTextDimensions(fitlabel, mLabelFont)[1];
		}
		dc.fillRectangle(0, labelY, width, timerMinuteHeight * minutesToLoad);
		dc.fillRectangle(0, labelY + timerMinuteHeight * minutesToLoad,
							width * (secondsMod60 / 60.0), timerMinuteHeight);

        dc.setColor(fgColor, Gfx.COLOR_TRANSPARENT);

        // Draw the field label
		if (drawLabel) {
	        dc.drawText(width / 2, LABEL_Y_OFFSET, mLabelFont, fitlabel, Gfx.TEXT_JUSTIFY_CENTER);
        }

        // Update direction icon
		if ((dirSize > 0) && !dirStr.equals("")) {
            var angle = -1;
            var poly = -1;
			if (dirStr.equals("SingleUp")) {
	            angle = 0;
	            poly = arrow;
			} else if (dirStr.equals("DoubleUp")) {
	            angle = 0;
	            poly = doubleArrow;
			} else if (dirStr.equals("FortyFiveUp")) {
	            angle = 45;
	            poly = arrow;
			} else if (dirStr.equals("FortyFiveDown")) {
	            angle = 135;
	            poly = arrow;
			} else if (dirStr.equals("SingleDown")) {
	            angle = 180;
	            poly = arrow;
			} else if (dirStr.equals("DoubleDown")) {
	            angle = 180;
	            poly = doubleArrow;
			} else if (dirStr.equals("Flat")) {
	            angle = 90;
	            poly = arrow;
			}
			if (angle >= 0) {
/*
	        if (dirSwitch.hasKey(dirStr)) {
	            var angle = dirSwitch[dirStr][0];
	            var poly = dirSwitch[dirStr][1];
*/
	            var polyXform = transformCoords(poly, angle, dirSize, [dirIconX, dirIconY]);
	            dc.setColor(dirFgColor, Gfx.COLOR_TRANSPARENT);
	 	        dc.fillPolygon(polyXform);
		        dc.setColor(fgColor, Gfx.COLOR_TRANSPARENT);
	        }
        }

		// Update status, data...
        if (!errorStr.equals("")) {
 	        dc.drawText(width/2, data1Y + 10, errorFont, errorStr, xAlignment);
		} else if (mDataFont1 != null) {
			var str = bgStr.toString();
			// for "visual alarms":
	        // var dimensions = dc.getTextDimensions(bgStr1, mDataFont1);
	        // dc.setColor(Gfx.COLOR_RED, Gfx.COLOR_RED);
	        // dc.fillRectangle(0, data1Y, dimensions[0], dimensions[1]);
	        // dc.setColor(fgColor, Gfx.COLOR_TRANSPARENT);
 	        dc.drawText(data1X, data1Y, mDataFont1, str, xAlignment);
			if (bgOld) {
            	strikeThrough(dc, str, mDataFont1, data1X, data1Y);
			}
 	    }

		if (mDataFont2 != null) {
			var str = elapsedStr;
 	        dc.drawText(data2X, data2Y, mDataFont2, str, xAlignment);
        }

		if (mDataFont3 != null) {
	        if (!monitorStr.equals("")) {
	            dc.setColor(Gfx.COLOR_RED, Gfx.COLOR_TRANSPARENT);
	 	        dc.drawText(data3X, data3Y, mDataFont3, monitorStr, xAlignment3);
		        dc.setColor(fgColor, Gfx.COLOR_TRANSPARENT);
	 	    } else {
				var str = rawBgStr;
				str = str + deltaStr;
	 	        dc.drawText(data3X, data3Y, mDataFont3, str, xAlignment3);
 	        }
		}
    	//Sys.println("out onUpdate()");
    }

}