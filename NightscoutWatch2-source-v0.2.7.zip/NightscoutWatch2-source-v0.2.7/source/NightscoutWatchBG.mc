/*
 * NightscoutWatch Garmin Connect IQ watchface
 * Copyright (C) 2017-2018 tynbendad@gmail.com
 * #WeAreNotWaiting
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3 of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   A copy of the GNU General Public License is available at
 *   https://www.gnu.org/licenses/gpl-3.0.txt
 */

using Toybox.Background;
using Toybox.Communications;
using Toybox.System as Sys;

// The Service Delegate is the main entry point for background processes
// our onTemporalEvent() method will get run each time our periodic event
// is triggered by the system.

(:background)
class BgbgServiceDelegate extends Toybox.System.ServiceDelegate {
    var receiveCtr = 0;
    var bgdata = {};
    var reqNum = 0;
    var propReq = {};
    var bgMemTiny = false;

    enum {
        fetchModeNormal     = 0,
        fetchModeNormalMin  = 1,
        fetchModeDevice     = 2,
        fetchModeDeviceMin1 = 3,
        fetchModeDeviceMin2 = 4,
        fetchModeDeviceMin3 = 5 }

    function printMem() {
        var myStats = Sys.getSystemStats();
        Sys.println("memory: total: " + myStats.totalMemory + ", used: " + myStats.usedMemory + ", free: " + myStats.freeMemory);
        //Sys.println("free memory: " + System.getSystemStats().freeMemory);
    }

    function initialize() {
		printMem();
        if (System.getSystemStats().freeMemory < 11250) {
        	bgMemTiny = true;	// need ~11250 bytes free in order to process devicestatus and some properties requests - most devices don't have enough memory for bg process.
        }
        Sys.println("bgMemTiny="+bgMemTiny);
        Sys.ServiceDelegate.initialize();
    }

	function cleanHashZero(data, keyHash) {
        if ((data != null) &&
            (data instanceof Dictionary)) {
	    	var keys = data.keys();
	    	for (var i=0; i<keys.size(); i++) {
	    		if (!keyHash.hasKey(keys[i])) {
	    			data.remove(keys[i]);
	    		}
	    	}
    	}
	}

    function cleanHashMany(data, key1, keyHash) {
        if ((data != null) &&
            (data instanceof Dictionary) &&
            data.hasKey(key1)) {
    		cleanHashZero(data[key1], keyHash);
    	}
    }

    function cleanHashOne(data, key1, key2) {
    	var keyHash = { key2=>1 };
    	cleanHashMany(data, key1, keyHash);
    }
/*
	function rcvPropStr(data) {	//tbd
	}
*/
    function onReceiveProperties(responseCode, data) {
        //Sys.println("in OnReceiveProperties");
        Sys.println("onReceiveProperties receiveCtr="+receiveCtr);
/*        if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof String)) {	//tbd
            rcvPropStr(data);
        } else*/ if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof Dictionary)) {
            if (data.hasKey("buckets")) {
            	var buckets = data["buckets"];
            	if ((buckets != null) &&
	            	(buckets instanceof Array)) {
	            	for (var i=0; i < buckets.size(); i++) {
	            		if ((buckets[i] != null) &&
	            			(buckets[i] instanceof Dictionary)) {
			                if (buckets[i].hasKey("mills")) {
			                	if (i == 0) {
				                    bgdata["elapsedMills"] = buckets[i]["mills"];
			                    }
			                	buckets[i]["mills"] = buckets[i]["mills"] / 1000;
			                }

			                if (buckets[i].hasKey("sgvs")) {
			                	var sgvs = buckets[i]["sgvs"];
					            var cleanBgnowSgvs = {"direction"=>1, "scaled"=>1};
			                	if (sgvs.size() > 0) {
				                    cleanHashZero(sgvs[0], cleanBgnowSgvs);
			                    }
			                	if (sgvs.size() > 1) {
				                    cleanHashZero(sgvs[1], cleanBgnowSgvs);
			                    }
			                }
				            var cleanBgnow = {"last"=>1, "mills"=>1};
				            if (i == 0) {
				                cleanBgnow["sgvs"] = 1;
				            }
			                cleanHashZero(buckets[i], cleanBgnow);
		                }
	                }
                }
            }

            // Clean (i.e., prune) the incoming data, instead of interpreting or copying it
            // in this way we can use as little memory/instructions as possible in the background process
            cleanHashOne(data, "basal", "display");
            cleanHashOne(data, "delta", "display");
            var cleanRawbg = {"mgdl"=>1, "noiseLabel"=>1};
            cleanHashMany(data, "rawbg", cleanRawbg);
            var cleanCage = {"age"=>1, "found"=>1};
            cleanHashMany(data, "cage", cleanCage);

	    	for (var i=0; i<data.keys().size(); i++) {
				var key1 = data.keys()[i];
	            bgdata["prop"][key1] = data[key1];
	            //Sys.println("prop: "+key1+"="+data[key1]);
			}
            //Sys.println("propReq: " + propReq);
            printMem();
            if (propReq.size() > 0) {
	            myWebRequest(true, 0, false);
            } else if (bgMemTiny) {
	            myWebRequest(true, -1, false);
            }
        } else {
            Sys.println("Prop resp: " + responseCode);
            if (!myWebRequest(false, 0, false)) {
	            bgdata["httpfail"] = true;
	            if (responseCode == Communications.BLE_CONNECTION_UNAVAILABLE) {
		            bgdata["blefail"] = true;
	            }
            }
        }
        receiveCtr--;
        if (receiveCtr == 0) {
            printMem();
	        Sys.println("out OnReceiveProperties - exit");
        	//Sys.println("pr bgdata="+bgdata);
            Background.exit(bgdata);
        }
        //Sys.println("out OnReceiveProperties");
    }

/*tbd
	function jsonParseDict(data, key) {
		if ((data != null) &&
			(data instanceof String) &&
			!data.equals("")) {
			var state_havekey=false;
			var state_havevalue=false;
			var chArray=data.toCharArray();
			for(var i=0; i<chArray.size(); i++) {
				if (chArray[i] == '"') {
					state_instring = !state_instring;
				}
				if (!state_instring) {
					if (chArray[i] == '{' || chArray[i] == ',') {
						state_inkey=true;
					}
				}
			}
			//tbd
			return "";
		} else {
			return "";
		}
	}

	function jsonParseArray(data, index) {
		// negative index starts from array end (-1 = last array entry)
		if ((data != null) &&
			(data instanceof String) &&
			!data.equals("")) {
			//tbd
			return "";
		} else {
			return "";
		}
	}
	
	function rcvDevStr(data) { //tbd
        var devRequestDone = true;
		var data0 = jsonParseArray(data, 0);
		var loop = jsonParseDict(data0, "loop");
		var pump = jsonParseDict(data0, "pump");
		var uploader = jsonParseDict(data0, "uploader");
		var uploaderBattery = jsonParseDict(data0, "uploaderBattery");
		var openaps = jsonParseDict(data0, "openaps");
		var battery = "";
		var failureReason = "";
		var predicted = "";
		var cob = "";
		var iob = "";
		var enacted = "";
		var values = "";
		var rate = "";
		var duration = "";
		var iobiob = "";
		var reservoir = "";
		var pump_status = "";
		var bolusiob = "";
		var openaps_timestamp = "";
		var suggested = "";
		var eventualBG = "";

		if (!loop.equals("")) {
			battery = jsonParseDict(uploader, "battery");
			failureReason = jsonParseDict(loop, "failureReason");
			predicted = jsonParseDict(loop, "predicted");
			cob = jsonParseDict(loop, "cob");
			iob = jsonParseDict(loop, "iob");
			enacted = jsonParseDict(loop, "enacted");
        	if (!failureReason.equals("")) {
        		failureReason = 1;
                bgdata["httpfaildevice"] = true;
        	}
        	if (!predicted.equals("")) {
        		values = jsonParseDict(predicted, "values");
        		var lastPredicted = jsonParseArray(values, -1);
        		values = [ lastPredicted ];
        	}
			rate = jsonParseDict(loop, "rate");
			duration = jsonParseDict(loop, "duration");
			iobiob = jsonParseDict(iob, "iob");
		}

		if (!pump.equals("")) {
			battery = jsonParseDict(pump, "battery");
			reservoir = jsonParseDict(pump, "reservoir");
			pump_status = jsonParseDict(pump, "status");
			iob = jsonParseDict(pump, "iob");
			bolusiob = jsonParseDict(iob, "bolusiob");
		}

		if (!openaps.equals("")) {
			iob = jsonParseDict(openaps, "iob");
			iobiob = jsonParseDict(iob, "iob");
			rate = jsonParseDict(enacted, "rate");
			duration = jsonParseDict(enacted, "duration");
			openaps_timestamp = jsonParseDict(suggested, "timestamp");
			eventualBG = jsonParseDict(suggested, "eventualBG");
			cob = jsonParseDict(suggested, "COB");

            //bgdata["dev1"] = data; //tbd
        } else {
			if (!pump.equals("") && loop.equals("")) {
	            //bgdata["dev1"] = data; //tbd
                // load additional loop devicestatus:
                myWebRequest(true, fetchModeDevice, true);
	 		  	devRequestDone = false;
            } else {
		        //bgdata["dev2"] = data; //tbd
            }
        }

    	return devRequestDone;
	}
*/
    function onReceiveDevice(responseCode, data) {
        //Sys.println("in OnReceiveDevice");
        Sys.println("onReceiveDevice receiveCtr="+receiveCtr);
        var devRequestDone = true;
/*   	    if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof String)) {	//tbd
            devRequestDone = rcvDevStr(data);
        } else
*/
        if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof Array) &&
            (data.size() > 0) &&
            (data[0] instanceof Dictionary)) {

            var cleanDevice = {"loop"=>1, "pump"=>1, "uploader"=>1, "uploaderBattery"=>1, "openaps"=>1};
            cleanHashZero(data[0], cleanDevice);

            // Clean (i.e., prune) the incoming data, instead of interpreting or copying it
            // in this way we can use as little memory/instructions as possible in the background process
            if (data[0].hasKey("loop")) {
            	var cleanDev2 = {"loop"=>1, "uploader"=>1, "pump"=>1};
            	cleanHashZero(data[0], cleanDev2);
            	cleanHashOne(data[0], "uploader", "battery");
            	var cleanLoop = {"failureReason"=>1, "predicted"=>1, "cob"=>1, "iob"=>1, "enacted"=>1};
            	cleanHashMany(data[0], "loop", cleanLoop);
            	if (data[0]["loop"].hasKey("failureReason")) {
            		data[0]["loop"]["failureReason"] = 1;
	                bgdata["httpfaildevice"] = true;
            	}

            	if (data[0]["loop"].hasKey("predicted") &&
            		(data[0]["loop"]["predicted"] != null) &&
            		(data[0]["loop"]["predicted"] instanceof Dictionary) &&
            		data[0]["loop"]["predicted"].hasKey("values") &&
                    (data[0]["loop"]["predicted"]["values"].size() > 0)) {
                    data[0]["loop"]["predicted"]["values"] = [ data[0]["loop"]["predicted"]["values"][data[0]["loop"]["predicted"]["values"].size()-1] ];
                }
	            var cleanEnacted = {"rate"=>1, "duration"=>1};
	            cleanHashMany(data[0]["loop"], "enacted", cleanEnacted);
            	cleanHashOne(data[0]["loop"], "iob", "iob");
        	}

			if (data[0].hasKey("pump")) {
            	var cleanPump = {"battery"=>1, "reservoir"=>1, "status"=>1, "iob"=>1};
	            cleanHashMany(data[0], "pump", cleanPump);
	            cleanHashOne(data[0]["pump"], "iob", "bolusiob");
            }

            if (data[0].hasKey("openaps")) {

	            cleanHashOne(data[0]["openaps"], "iob", "iob");
	            var cleanEnacted = {"rate"=>1, "duration"=>1};
	            cleanHashMany(data[0]["openaps"], "enacted", cleanEnacted);
	            var cleanSuggested = {"timestamp"=>1, "eventualBG"=>1, "COB"=>1};
	            cleanHashMany(data[0]["openaps"], "suggested", cleanSuggested);

	            bgdata["dev1"] = data;
            } else {
				if (data[0].hasKey("pump") && !data[0].hasKey("loop")) {
		            bgdata["dev1"] = data;
	                // load additional loop devicestatus:
	                myWebRequest(true, fetchModeDevice, true);
		 		  	devRequestDone = false;
	            } else {
			        bgdata["dev2"] = data;
	            }
            }
        } else {
            Sys.println("Dev resp: " + responseCode + ", data=" + data);
            if (bgdata.hasKey("dev1") ||
                bgdata.hasKey("dev2")) {
                // we're good - no loop or openaps data is available, but we did get device data.
            } else {
                bgdata["httpfaildevice"] = true;
            }
        }
        receiveCtr--;
        if (devRequestDone) {
            data = null;	// free memory for next fetch
            myWebRequest(true, 0, false);
        }
        //Sys.println("dev bgdata="+bgdata);
        Sys.println("out OnReceiveDevice");
    }

    function onReceiveSGV(responseCode, data) {
        //Sys.println("in OnReceiveSGV");
        //myPrintLn("response: " + responseCode.toString());
        if ((responseCode == 200) &&
            (data != null) &&
        	(data instanceof Array) &&
            (data.size() > 1) &&
            (data[0] != null) &&
            (data[1] != null) &&
            !data[0].isEmpty() &&
            !data[1].isEmpty()
            ) {
            bgdata["sgv"] = data;
            var elapsedMills;
            elapsedMills = 0;
            if (data[0].hasKey("sgv") &&
                data[0].hasKey("date") &&
                data[0].hasKey("direction")
                ) {
                elapsedMills = data[0]["date"];
	            //Sys.println("valid data: " + data);
            //} else {
	            //Sys.println("invalid data: " + data);
            }
            bgdata["elapsedMills"] = elapsedMills;
        } else {
            Sys.println("SGV resp: " + responseCode.toString());
            //Sys.println("data: " + data);
            if ((reqNum >= 4 /*maxRequests*/) || !myWebRequest(false, 0, false)) {
	            bgdata["httpfail"] = true;
	            if (responseCode == Communications.BLE_CONNECTION_UNAVAILABLE) {
		            bgdata["blefail"] = true;
	            }
            }
        }
		receiveCtr--;
        if (receiveCtr == 0) {
            printMem();
            Sys.println("out OnReceiveSGV - exit");
            //Sys.println("bgdata="+bgdata);
	        Background.exit(bgdata);
        }
        //Sys.println("out OnReceiveSGV");
    }

    function onReceiveSugarmate(responseCode, data) {
        //Sys.println("in OnReceiveSugarmate");
        //myPrintLn("response: " + responseCode.toString());
        if ((responseCode == 200) &&
            (data != null) &&
            (data instanceof Dictionary)) {
            bgdata["sugarmate"] = data;
            var elapsedMills;
            elapsedMills = 0;
            if (data.hasKey("value") &&
                data.hasKey("x")) {
                elapsedMills = data["x"].toLong() * 1000;
	            //Sys.println("valid data: " + data);
            //} else {
	            //Sys.println("invalid data: " + data);
            }
            bgdata["elapsedMills"] = elapsedMills;
        } else {
            //Sys.println("Sugarmate resp: " + responseCode.toString());
            //Sys.println("data: " + data);
            if ((reqNum >= 4 /*maxRequests*/) || !myWebRequest(false, 0, false)) {
	            bgdata["httpfail"] = true;
	            if (responseCode == Communications.BLE_CONNECTION_UNAVAILABLE) {
		            bgdata["blefail"] = true;
	            }
            }
        }
		receiveCtr--;
        if (receiveCtr == 0) {
            printMem();
            //Sys.println("out OnReceiveSugarmate - exit, bgdata="+bgdata);
	        Background.exit(bgdata);
        }
        //Sys.println("out OnReceiveSugarmate");
    }

	function jsonLookup(data, spec) {
		var answer = null;
		while (!spec.equals("")) {
			var entry = spec.find(".");
			var array = spec.find("[");
			if (((entry != null) &&
				 (array != null) &&
				 (array < entry)) ||
				((entry == null) &&
				 (array != null))) {
			 	// process array
			 	var endarray = spec.find("]");
			 	if (endarray != null) {
		        	var index = spec.substring(array+1,endarray);
		        	//Sys.println("index="+index);
				    spec = spec.substring(endarray+1,spec.length());
				    if ((index != null) &&
				    	(data instanceof Array) &&
				    	(data.size() > index.toNumber())) {
				    	data = data[index.toNumber()];
			    	} else {
				    	Sys.println("index error: " + index);
					    return answer;
			    	}
			    } else {
			    	Sys.println("spec string error: " + spec);
				    return answer;
			    }
		    } else if (entry != null) {
		    	// process entry
			 	var endentry1 = spec.find("[");
			 	var endentry2 = spec.substring(entry+1,spec.length()).find(".");
			 	if ((endentry1 != null) &&
			 		(endentry2 != null)) {
			 		if (endentry2+1 < endentry1) {
			 			endentry1 = endentry2+1;
			 		}
		 		} else if (endentry2 != null) {
		 			endentry1 = endentry2+1;
		 		} else if (endentry1 == null) {
		 			endentry1 = spec.length();
		 		}
	        	var ename = spec.substring(entry+1,endentry1);
	        	//Sys.println("ename="+ename);
			    spec = spec.substring(endentry1,spec.length());
	        	//Sys.println("spec="+spec);
			    if ((ename != null) &&
			    	(ename instanceof String) &&
			    	(ename != "") &&
			    	(data instanceof Dictionary) &&
			    	data.hasKey(ename)) {
			    	data = data[ename];
		    	} else {
		    		Sys.println("entry error: "+ename);
				    return answer;
		    	}
		    }
		}
		answer = data;
		//Sys.println("answer: "+answer);
		return answer;
	}
	
    function onReceiveOWM(responseCode, data) {
        //Sys.println("in OnReceiveOWM");
        //myPrintLn("response: " + responseCode.toString());
        var jsonTemp = ".main.temp";	// format: integer
        var jsonIcon = ".weather[0].icon";	// format: string
        var jsonMain = ".weather[0].main";	// format: string
        Sys.println("onReceiveOWM receiveCtr="+receiveCtr);
        if ((responseCode == 200) &&
            (data != null)
            ) {
            var temp = jsonLookup(data, jsonTemp);
            if (temp instanceof Float) {
            	bgdata["owmtemp"] = temp.format("%.0f");
        	}
            bgdata["owmicon"] = jsonLookup(data, jsonIcon);
            bgdata["owmmain"] = jsonLookup(data, jsonMain);
        } else {
            Sys.println("OWM resp: " + responseCode.toString());
            //Sys.println("data: " + data);
        }
		receiveCtr--;
        if (receiveCtr == 0) {
            printMem();
            //Sys.println("out OnReceiveOWM - exit, bgdata="+bgdata);
	        Background.exit(bgdata);
        }
        //Sys.println("out OnReceiveOWM");
    }

	function removeWhitespace(url) {
		while(!url.equals("") &&
		      url.substring(0,1).equals(" ")) {
		    url = url.substring(1,url.length());
        }
		while(!url.equals("") &&
		      url.substring(url.length()-1,url.length()).equals(" ")) {
		    url = url.substring(0,url.length()-1);
        }
        while(url.substring(url.length()-1,url.length()).equals("/")) {
		    url = url.substring(0,url.length()-1);
        }
        if (url.substring(url.length()-9,url.length()).equals("/sgv.json")) {
		    url = url.substring(0,url.length()-9);
        }
		return url;
	}

    function makeNSURL(fetchMode, loop) {
        var thisApp = Application.getApp();
        var sugarmate = false;
        var url = thisApp.getProperty("nsurl");
		if (url == null) { url = ""; }

		url = removeWhitespace(url);

        if (!url.equals("")) {
        	var options = "";
	        if (url.find("://") == null) {
    	        url = "https://" + url;
        	}
	        if (url.find("?") != null) {
	        	// support token based nightscout authentication, set NS URL = your-site.herokuapp.com?token=your-token
	        	options = "&" + url.substring(url.find("?")+1,url.length());
			    url = url.substring(0,url.find("?"));
				url = removeWhitespace(url);
	        }
	        if (url.find("sugarmate.io/api/") != null) {
	        	sugarmate = true;
		        if (url.toLower().find("http://") != null) {
				   url = url.substring(url.toLower().find("http://")+7,url.length());
	    	       url = "https://" + url;
    	        }
	        } else if ((propReq.size() == 0) && (fetchMode >= fetchModeDevice) && !bgMemTiny) {
	        	if (!loop) {
		            url = url +
		                    "/api/v1/devicestatus.json?count=1&find[pump][$exists]";  // loop and openaps info available here is more compact
		            // Note: Loop deviceStatus is requested separately if we don't find openaps key along with pump key.
	            } else {
	                url = url +
	                        "/api/v1/devicestatus.json?count=1&find[loop][$exists]";  // loop and openaps info available here is more compact
                }
            } else if (fetchMode < 0) {
	            url = url + "/api/v1/entries/sgv.json?count=3";
	        } else {
	            url = url +
//	                    "/api/v2/properties/buckets,rawbg,delta,cage"; // pump returns too much for tiny background process
//	                    "/api/v2/properties/buckets,delta,cage,basal"; // pump returns too much for tiny background process
	                    "/api/v2/properties/"; // pump returns too much for tiny background process
	            if (propReq.size() == 0) {
	            	if (bgMemTiny) {
			            propReq = {/*"buckets"=>1,*/"delta,cage"=>1};
	            	} else {
			            propReq = {"buckets"=>1,"rawbg,delta,cage"=>1,"basal"=>1};
			            //propReq = {"buckets,rawbg,delta,cage"=>1};
		            }
		            bgdata["prop"] = {};
	            }
	            var key1 = propReq.keys()[0];
	            propReq.remove(key1);
	            url = url + key1;
	            // must end with a ? param so we can blindly add & param if there was a user supplied ? param (replaced with & above)
	            url = url + "?foo=1";	
	        }
	        url = url + options;
    	}
        return [url, sugarmate];
	}

    function makeOfflineURL() {
        var thisApp = Application.getApp();
		var url = thisApp.getProperty("offlineUrl");
		if (url == null) { url = ""; }

		url = removeWhitespace(url);

        if (url.equals("")) {
        	if ((reqNum % 2) == 0) {
        		url = "X";
        	} else {
        		url = "S";
        	}
        }

        if (url.substring(0,1).toUpper().equals("X")) {
            url = "http://127.0.0.1:17580"; // xdrip+ local web server
        } else if (url.substring(0,1).toUpper().equals("S")) {
            url = "http://127.0.0.1:1979"; // Spike web server
        }

        if (!url.equals("")) {
	        if (url.find("://") == null) {
	            url = "http://" + url;
	        }
	        url = url + "/sgv.json?count=3";
        }
        //url = "https://tynbendad.github.io/pumptest/api/v1/xdrip-other-sgv.json";
        //url = "https://tynbendad.github.io/pumptest/api/v1/xdrip-g4-sgv.json";
        //url = "https://tynbendad.github.io/pumptest/api/v1/nightscout-sgv.json";
        //url = "https://tynbendad.github.io/pumptest/api/v1/tomato1.json";
        //url = "https://tynbendad.github.io/pumptest/api/v1/diabox2023-2.json";
        return url;
    }

    function myWebRequest(ns, fetchMode, loop) {
        var nsurlRet = makeNSURL(fetchMode, loop);
        var url = nsurlRet[0];
        var sugarmate = nsurlRet[1];

        //    url = "https://tynbendad.github.io/pumptest/api/v1/test3.json";    // for testing
        //    url = "https://tynbendad.github.io/pumptest/api/v2/properties/simpletest2.json";   // for testing
        if (ns && !url.equals("")) {
	        //Sys.println("ns url: " + url);
            receiveCtr++;
    		reqNum++;
    		if (sugarmate) {
	            Communications.makeWebRequest(url, {}, {}, method(:onReceiveSugarmate));
    		} else if ((fetchMode >= fetchModeDevice) && !bgMemTiny) {
	            printMem();
	            //Sys.println("initial Device request");
	            Communications.makeWebRequest(url, {}, {
//                                            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN	//tbd
		            }, method(:onReceiveDevice));
            } else if (fetchMode < 0) {
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
            } else {
	            //Sys.println("initial Properties request");
	            Communications.makeWebRequest(url, {}, {
//                                            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN	//tbd
		            }, method(:onReceiveProperties));
            }
            return true;
        } else {
        	url = makeOfflineURL();
            if (!url.equals("")) {
                //Sys.println("ol url: " + url.toString());
	            receiveCtr++;
	    		reqNum++;
	            //Sys.println("initial SGV request");
                Communications.makeWebRequest(url, {}, { :method => Communications.HTTP_REQUEST_METHOD_GET,
                                                         :headers => {                                           // set headers
                                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
                                                         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
                                                       }, method(:onReceiveSGV));
	            return true;
            }
        }
        return false;
	}

	function weatherWebRequest() {
		var owmAPIKey = Application.getApp().getProperty("owmAPIKey");
		if (owmAPIKey == null) { owmAPIKey = ""; }
		var zipCode = Application.getApp().getProperty("zipCode");
		if (zipCode == null) { zipCode = ""; }
		while (zipCode.find(" ") != null) {
			var spaceIdx = zipCode.find(" ");
			var zipLen = zipCode.length();
        	zipCode = zipCode.substring(0,spaceIdx) + "%20" + zipCode.substring(spaceIdx+1,zipLen);
		}
		var tempUnits = Application.getApp().getProperty("tempUnits");
		if (tempUnits == null) { tempUnits = 0; }
		if (((tempUnits == 0) || (tempUnits == 1)) &&
			!zipCode.equals("") &&
			!owmAPIKey.equals("")) {
			var units = "imperial";
	        bgdata["owmunits"] = "°F";
			if (tempUnits == 1) {
				units = "metric";
	            bgdata["owmunits"] = "°C";
			}
	        var owmurl = "https://api.openweathermap.org/data/2.5/weather?zip=" + zipCode + "&units=" + units + "&APPID=" + owmAPIKey;
	        // Sys.println("owmurl="+owmurl);
	        receiveCtr++;
	        Sys.println("weatherWebRequest receiveCtr="+receiveCtr);
	        Communications.makeWebRequest(owmurl, {},
	        							  { :method => Communications.HTTP_REQUEST_METHOD_GET,
	                                        :headers => {                                           // set headers
	                                                   "Content-Type" => Communications.REQUEST_CONTENT_TYPE_URL_ENCODED},
	                                        :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
	                                      },
	                                      method(:onReceiveOWM));
        }
	}


    function onTemporalEvent() {
        Sys.println("in onTemporalEvent");
		var fetchMode = Application.getApp().getProperty("fetchMode");
		if (fetchMode == null) { fetchMode = 3; }
        receiveCtr = 0;
        reqNum = 0;
        myWebRequest(true, fetchMode, false);
        Sys.println("onTemporalEvent receiveCtr="+receiveCtr);
        weatherWebRequest();
        Sys.println("out onTemporalEvent");
    }
}
